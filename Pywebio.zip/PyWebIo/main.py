from pywebio import start_server
from pywebio.input import *
from pywebio.output import *
from pywebio.session import defer_call, info as session_info, run_async, run_js

put_markdown("## 🧊 Добро пожаловать в наш Уютный Форум ))")

put_table([
	['Name','Link','News'],
	['Винница',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Обновление Beta 1.0'],
	['Кропивницкий (Кировоград)',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Добавленно'],
	['Полтава',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'1) Главное меню пишеться не на Html а на Pywebio'],
	['Харьков',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'2) Скоро код програмы станет полностью открытым'],
	['Днепр (Днепропетровск)',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'3)Лимит сообщений увеличен на 100'],
	['Луганск',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Beta 1.1'],
	['Ровно',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Меню под разделы добавлено'],
	['Херсон',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Баго фикс'],
	['Донецк',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Beta 1.2'],
	['Луцк',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'В чатах Типа Беженцы , Скидки , Работа , Докторы , Волонтеры измененно приветствие'],
	['Симферополь',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),'Убран мечь с низу'],
	['Хмельницкий',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],		
	['Житомир',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Львов',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Сумы',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>')],
	['Черкассы',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Запорожье',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Николаев',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Чернигов',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Ивано-Франковск',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Одесса',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Ужгород',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Черновцы',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Киев',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],
	['Тернополь',put_html('<a href="http://127.0.0.1:8080/">Chat<a/>'),''],	

])

popup('Хмм кто Автор ???', [
    put_html('## 🧠 Автор Миша Осипенко	'),
])

put_html('<a href="https://helpukrainearmynow.com/">HELP WORLD HELP UKRAIN ARMY</a>')
if __name__ == "__main__":
    start_server(main, debug=True, port=8080, cdn=False)
