from pywebio import start_server
from pywebio.input import *
from pywebio.output import *
from pywebio.session import defer_call, info as session_info, run_async, run_js


put_table([
	[put_html('<a href=''>Поиск Докторов 👀</a>'),'  ',put_html('<a href=''>Волонтерство 👊</a>'),'		',put_html('<a href = "">Беженство 💥</a>'),'		',put_html('<a href = "">Работа 💪</a>'),'		',put_html('<a href = "">Скидки 🆓</a>')]
	])

put_markdown("## 🧊 Добро пожаловать в Выбор категорий города Запорожье ))")

put_table([
	['Поиск Докторов 👀' , 'Поиск нужных Доктаров в вашем городе например можно найти Окулиста'],
	['Волонтерство 👊' , 'Хотите Стать Волонтером ? Тогда вы здесь сможете найти компании Волонтеров'],
	['Беженство 💥', 'Хотите Стать Беженством ? Здесь вы сможете получить опыт от других беженцев или найти дом'],
	['Работа 💪','Здесь вы можете найти работу мечты'],
	['Скидки 🆓' , 'Здесь вы можете найти выгодные цены в столь тяжелое для економики время']
	])

if __name__ == "__main__":
    start_server(main, debug=True, port=8080, cdn=False)